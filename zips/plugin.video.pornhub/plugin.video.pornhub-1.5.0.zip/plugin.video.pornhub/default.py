import urllib,urllib2,re,xbmcplugin,xbmcgui
import xbmcaddon

#Porn Hub - Blazetamer.
addon = xbmcaddon.Addon ('plugin.video.pornhub')

url= 'http://www.pornhub.com/'

#PATHS

addonPath = addon.getAddonInfo('path')
artPath = addonPath + '/art/'
fanartPath = addonPath + '/art/'
baseurl = 'http://www.pornhub.com'
#HOOKS
settings = xbmcaddon.Addon(id='plugin.video.pornhub')

def CATEGORIES():
    
    addDir('Amature Video','http://www.pornhub.com/video?c=3',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/3.jpg')
    addDir('Bi-Sexual','http://www.pornhub.com/video?c=76',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/76.jpg')
    addDir('Bondage','http://www.pornhub.com/video?c=10',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/10.jpg')
    addDir('Big Tits','http://www.pornhub.com/video?c=8',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/8.jpg')
    addDir('Threesome','http://www.pornhub.com/video?c=65',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/65.jpg')
    addDir('Celebrity','http://www.pornhub.com/video?c=12',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/12.jpg')
    addDir('Pornstar','http://www.pornhub.com/video?c=30',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/30.jpg')
    addDir('Female Friendly','http://www.pornhub.com/video?c=73',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/73.jpg')
    addDir('Masturbation ','http://www.pornhub.com/video?c=22',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/22.jpg')
    addDir('Cumshots','http://www.pornhub.com/video?c=16',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/16.jpg')
    addDir('Toys','http://www.pornhub.com/video?c=23',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/23.jpg')
    addDir('College','http://www.pornhub.com/categories/college',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/79.jpg')
    addDir('Big Dick','http://www.pornhub.com/video?c=7',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/7.jpg')
    addDir('Ebony','http://www.pornhub.com/video?c=17',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/17.jpg')
    addDir('Gay','http://www.pornhub.com/gayporn',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/63.jpg')
    addDir('Japanese','http://www.pornhub.com/video?c=111',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/111.jpg')
    addDir('Lesbian ','http://www.pornhub.com/video?c=27',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/27.jpg')
    addDir('Latina','http://www.pornhub.com/video?c=26',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/26.jpg')
    addDir('Massage','http://www.pornhub.com/video?c=78',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/78.jpg')
    addDir('Interracial','http://www.pornhub.com/video?c=25',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/25.jpg')
    addDir('MILF','http://www.pornhub.com/video?c=29',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/29.jpg')
    addDir('Uniforms','http://www.pornhub.com/video?c=81',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/81.jpg')
    addDir('Webcam','http://www.pornhub.com/video?c=61',1,'http://cdn1a.static.pornhub.phncdn.com/images/categories/61.jpg')
    addDir('Search>>>','http://www.pornhub.com/video/search?search=',10,'')
    addDir('Top Rated','http://www.pornhub.com/video?o=tr',1,'')
    addDir('All Videos','http://www.pornhub.com/video',1,'')

    
def OPEN_URL(url):
  req=urllib2.Request(url)
  req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
  response=urllib2.urlopen(req)
  link=response.read()
  response.close()
  return link    
    
def INDEX(url):
    link=OPEN_URL(url)
    match=re.compile('href="(.+?)" title="(.+?)" class=".+?" data-related-url=".+?">\r\n\t\t\t\t\t\t\t\t\t<div class=".+?">\r\n\t\t\t\t<var class=".+?">.+?</var>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t<img src=".+?" alt=".+?" data-smallthumb=".+?" data-mediumthumb="(.+?)"').findall(link)
    for url, name,thumb in match:
            addDir(name,baseurl + url,2,thumb)
                
def VIDEOLINKS(url,name):
        link=OPEN_URL(url)
        match=re.compile('iframe src=&quot;(.+?)&quot;').findall(link)
        for url in match:
                 EMBED(url,name)

def EMBED(url,name):
        link=OPEN_URL(url)
        match=re.compile('data-src="(.+?)" poster="(.+?)"').findall(link)
        for url,iconimage in match:
                 addLink(name,url,iconimage)                 

                 
#Set View Function
def set_view(content='none',view_mode=50,do_sort=False):
	h=int(sys.argv[1])
	if (content is not 'none'): xbmcplugin.setContent(h, content)
	if (tfalse(addst("auto-view"))==True): xbmc.executebuiltin("Container.SetViewMode(%s)" % str(view_mode))                

#Start Ketboard Function                
def _get_keyboard( default="", heading="", hidden=False ):
	""" shows a keyboard and returns a value """
	keyboard = xbmc.Keyboard( default, heading, hidden )
	keyboard.doModal()
	if ( keyboard.isConfirmed() ):
		return unicode( keyboard.getText(), "utf-8" )
	return default


#Start Search Function
def SEARCH(url):
	searchUrl = url 
	vq = _get_keyboard( heading="Searching  PornHub!!" )
	# if blank or the user cancelled the keyboard, return
	if ( not vq ): return False, 0
	# we need to set the title to our query
	title = urllib.quote_plus(vq)
	searchUrl += title 
	print "Searching URL: " + searchUrl 
	INDEX(searchUrl)        

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param





def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name,iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo('video',{'Title':name,'Genre':'Live','Studio':name})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        xbmc.sleep(1000)
        xbmc.Player ().play(url, liz, False)
        return ok
    #xbmc.PLAYER_CORE_PAPLAYER


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        xbmc.executebuiltin("Container.SetViewMode(500)")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        INDEX(url)
        

elif mode==2:
        print ""+url
        VIDEOLINKS(url,name)

#For Search Function
elif mode==10:
        print ""+url
        SEARCH(url)        



xbmcplugin.endOfDirectory(int(sys.argv[1]))


